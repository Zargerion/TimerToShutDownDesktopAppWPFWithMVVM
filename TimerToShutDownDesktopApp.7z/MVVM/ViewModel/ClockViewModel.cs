﻿using TimerToShutDownDesktopApp.Core;

namespace TimerToShutDownDesktopApp.MVVM.ViewModel
{
    internal class ClockViewModel : ObservableObject
    {
        public ClockViewModel()
        {

        }

    }
}

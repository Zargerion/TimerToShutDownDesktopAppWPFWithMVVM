﻿using TimerToShutDownDesktopApp.Core;

namespace TimerToShutDownDesktopApp.MVVM.ViewModel
{
    internal class TimerViewModel : ObservableObject
    {
        public TimerViewModel()
        {

        }
    }
}
